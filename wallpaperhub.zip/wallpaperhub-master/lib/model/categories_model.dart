class CategoriesModel {
  String categoriesName;
  String imgUrl;
}
