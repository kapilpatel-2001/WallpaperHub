package com.example.wallpaperhub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
